#ifndef TRAP1_HPP
#define TRAP1_HPP

#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>

bool runTrap1(SDL_Window* window, SDL_Renderer* renderer,Uint32 gameStartTime, bool timerRunning);

#endif

