#ifndef TRAP2_HPP
#define TRAP2_HPP

#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>

bool runTrap2(SDL_Window* window, SDL_Renderer* renderer,Uint32 gameStartTime, bool timerRunning);

#endif

