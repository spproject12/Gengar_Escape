# Gengar-Escape-Whisper-of-Forbidden-Memories

Run File: ui_main.cpp

Run Command:g++ -std=c++17 music.cpp main_map.cpp ui_main.cpp trap1.cpp trap2.cpp trap3.cpp trap4.cpp -o prog -lSDL2 -lSDL2_image -lSDL2_ttf -lSDL2_mixer -ldl


Install Dependencies:
SDL, SDL_mixer, SDL_Image, SDL_timer, SDL_ttf, 
