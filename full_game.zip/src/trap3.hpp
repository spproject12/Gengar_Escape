#ifndef TRAP3_HPP
#define TRAP3_HPP

#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include <SDL2/SDL_ttf.h>

bool runTrap3(SDL_Window* window, SDL_Renderer* renderer,Uint32 gameStartTime, bool timerRunning);

#endif

